# LabShock Collector Audit Report

- UTC timestamp: 20260521T131120Z
- Lab directory: `/home/kali/labshock`
- OT Collector URL: `http://192.168.1.70:8088`
- DMZ Collector URL: `http://192.168.10.70:9000`
- OT container: `ot_collector`
- DMZ container: `dmz_collector`
- Event API sample limit: `5000`
- Synthetic API tests enabled: `0`
- Syslog injection tests enabled: `0`

## Purpose

This audit captures evidence for raw ingestion, parsing, normalization, enrichment, filtering/decision logic, JSONL storage, forwarding, and dashboard/API consistency.

## 0. Environment Baseline
Baseline files saved under `raw/`.
\n## 1. API Health And Runtime Snapshots
Saved API snapshots in `json/` and pretty versions in `raw/`.
\n## 2. Container And Runtime Evidence
Container logs and Docker inspect outputs captured.
\n## 3. Repository Source Evidence
Repository snippets captured when present.
\n## 4. JSONL Storage Validation
